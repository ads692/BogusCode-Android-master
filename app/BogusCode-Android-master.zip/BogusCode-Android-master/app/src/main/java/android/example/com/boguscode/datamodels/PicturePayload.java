package android.example.com.boguscode.datamodels;

import java.util.ArrayList;

public class PicturePayload {
    private ArrayList<PictureSizes> sizes;

    public PicturePayload(final ArrayList<PictureSizes> sizes) {
        this.sizes = sizes;
    }

    public ArrayList<PictureSizes> getSizes() {
        return sizes;
    }
}
