package android.example.com.boguscode.datamodels;

public class PictureSizes {
    private int width;
    private int height;
    private String link;

    public PictureSizes(final int width, final int height, final String link) {
        this.width = width;
        this.height = height;
        this.link = link;
    }

    public String getLink() {
        return link;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
