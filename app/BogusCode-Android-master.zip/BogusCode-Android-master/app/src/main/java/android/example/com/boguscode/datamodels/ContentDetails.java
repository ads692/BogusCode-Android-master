package android.example.com.boguscode.datamodels;

public class ContentDetails {
    private String name;
    private String type;
    private String link;
    private String created_time;
    private PicturePayload pictures;

    public ContentDetails(final String name, final String type, final String link, final String created_time, final PicturePayload pictures) {
        this.name = name;
        this.type = type;
        this.link = link;
        this.created_time = created_time;
        this.pictures = pictures;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getLink() {
        return link;
    }

    public String getCreated_time() {
        return created_time;
    }

    public PicturePayload getPictures() {
        return pictures;
    }
}
